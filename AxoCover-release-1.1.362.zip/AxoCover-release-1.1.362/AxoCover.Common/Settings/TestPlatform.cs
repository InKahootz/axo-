﻿namespace AxoCover.Common.Settings
{
  public enum TestPlatform
  {
    x86,
    x64
  }
}
