﻿using AxoCover.ViewModels;

namespace AxoCover.Views
{
  /// <summary>
  /// Interaction logic for ReleaseManagerView.xaml
  /// </summary>
  public partial class ReleaseManagerView : View<ReleaseManagerViewModel>
  {
    public ReleaseManagerView()
    {
      InitializeComponent();
    }
  }
}
