namespace AxoCover.Models.Testing.Data
{
  public enum CodeItemKind
  {
    Unknown,
    Solution,
    Project,
    Namespace,
    Class,
    Method,
    Data,
    Group
  }
}
