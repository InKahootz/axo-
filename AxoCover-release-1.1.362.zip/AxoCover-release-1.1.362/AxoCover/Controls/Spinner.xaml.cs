﻿using System.Windows.Controls;

namespace AxoCover.Controls
{
  /// <summary>
  /// Interaction logic for Spinner.xaml
  /// </summary>
  public partial class Spinner : UserControl
  {
    public Spinner()
    {
      InitializeComponent();
    }
  }
}
