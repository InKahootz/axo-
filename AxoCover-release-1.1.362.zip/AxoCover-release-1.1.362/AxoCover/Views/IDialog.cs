﻿using System.Windows;

namespace AxoCover.Views
{
  public interface IDialog
  {
    void InitializeWindow(Window window);
  }
}
