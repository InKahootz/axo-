﻿namespace AxoCover.Common.Extensions
{
  public enum CommunicationProtocol
  {
    Tcp,
    MemoryPipe
  }
}
