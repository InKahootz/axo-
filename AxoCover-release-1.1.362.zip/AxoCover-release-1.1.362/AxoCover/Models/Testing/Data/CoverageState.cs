namespace AxoCover.Models.Testing.Data
{
  public enum CoverageState
  {
    Unknown,
    Uncovered,
    Mixed,
    Covered
  }
}
