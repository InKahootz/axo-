﻿namespace AxoCover.Common.Settings
{
  public enum TestAdapterMode
  {
    Integrated,
    Standard
  }
}
