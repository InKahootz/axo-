﻿namespace AxoCover.Common.ProcessHost
{
  public enum RunnerMode
  {
    Unknown,
    Discovery,
    Execution
  }
}
